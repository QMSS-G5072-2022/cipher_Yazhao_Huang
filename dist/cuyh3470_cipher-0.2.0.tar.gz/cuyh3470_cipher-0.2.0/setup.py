# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

modules = \
['cuyh3470_cipher']
setup_kwargs = {
    'name': 'cuyh3470-cipher',
    'version': '0.2.0',
    'description': 'A package for doing great things!',
    'long_description': '# cuyh3470_cipher\n\nA package for doing great things!\n\n## Installation\n\n```bash\n$ pip install cuyh3470_cipher\n```\n\n## Usage\n\n- TODO\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`cuyh3470_cipher` was created by Yazhao Huang. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`cuyh3470_cipher` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'Yazhao Huang',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'py_modules': modules,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
